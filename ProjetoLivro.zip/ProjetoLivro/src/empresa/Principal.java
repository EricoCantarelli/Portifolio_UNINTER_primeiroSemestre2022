package empresa;

public class Principal {

	public static void main(String[] args) {
		LivroDigital ld = new LivroDigital("Senhor dos aneis",
				new Autor("Tolkien", "Britanico", "tolkien@email.com"),
				"Aventura",
				5,
				10000,
				3500);
		
		ld.info();
		
		
		LivroFisico lf = new LivroFisico("Star wars", 
				new Autor("George lucas","Americano", "george@email.com"),
				"Aventura",
				1,
				10,
				1);
		System.out.println();
		lf.info();
		
		System.out.println();
	
		Livro livro;
		
		livro = ld;
		
		livro.info();
		
		System.out.println();
		
		livro = lf;
		livro.info();
				

	}
	  

}
