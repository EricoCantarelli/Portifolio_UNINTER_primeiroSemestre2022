package empresa;

public class Principal {

	public static void main(String[] args) {
		
		
		
		Avaliacao Luigi = new Avaliacao();
		Avaliacao mario = new Avaliacao(7,4,10);
		Luigi.n1=8;
		Luigi.n2=3;
		Luigi.n3=7.5;
		
		System.out.println("Media Aritimetica do Mario: " + mario.mediaAritimetica());
		System.out.println("Media Ponderada do Mario: " + mario.mediaPonderada());
		
		System.out.println("Media Aritimetica do Luigi: " + Luigi.mediaAritimetica());
		System.out.println("Media Ponderada do Luigi: " + Luigi.mediaPonderada());
	

	}

}
