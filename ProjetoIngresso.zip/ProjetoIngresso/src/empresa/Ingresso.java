package empresa;

public class Ingresso {
	String NomeEvento;
	double valor;
	
	public Ingresso(String nomeEvento, double valor) {
		super();
		NomeEvento = nomeEvento;
		this.valor = valor;
	}

	public void info() {
		System.out.println("Nome Evento: " + NomeEvento);
		System.out.println("Valor: " + valor);
	}

}
