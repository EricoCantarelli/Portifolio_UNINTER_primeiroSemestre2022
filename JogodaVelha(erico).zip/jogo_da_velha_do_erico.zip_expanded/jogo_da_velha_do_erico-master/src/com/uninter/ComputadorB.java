package com.uninter;

import java.util.ArrayList;
import java.util.Random;

public class ComputadorB extends Jogador{
    
    @Override
    public String escolhe_jogada(ArrayList<String> posicoes_validas,String jogada_oponente,boolean is_jogada_oponente) {
        Random rand = new Random();
        String posicao_valida_aleatoria = "";
        Tabuleiro tab = new Tabuleiro();
        int jogada_int = Integer.parseInt(jogada_oponente);
        boolean valido;
        if(jogada_int<=3) {
        	//int x = ran.nextInt(max_val) + min_val;
        	int randlinha = rand.nextInt(3) +1;
        	valido = tab.validarjogada(String.valueOf(randlinha),posicoes_validas);
        	if(valido == true) {
        		posicao_valida_aleatoria = (String.valueOf(randlinha));	
        	} else {
        		posicao_valida_aleatoria = posicoes_validas.get(rand.nextInt(posicoes_validas.size()));
        		
        	}
        } else if((jogada_int >= 4) && (jogada_int <= 6)) {
        
        	int randlinha = rand.nextInt(6) +4;
        	valido = tab.validarjogada(String.valueOf(randlinha),posicoes_validas);
        	if(valido == true) {
        		posicao_valida_aleatoria = (String.valueOf(randlinha));	
        	} else {
        		posicao_valida_aleatoria = posicoes_validas.get(rand.nextInt(posicoes_validas.size()));
        		
        	}
        } else  {
        	
        	int randlinha = rand.nextInt(9) +7;
        	valido = tab.validarjogada(String.valueOf(randlinha),posicoes_validas);
        	if(valido == true) {
        		posicao_valida_aleatoria = (String.valueOf(randlinha));	
        	} else {
        		posicao_valida_aleatoria = posicoes_validas.get(rand.nextInt(posicoes_validas.size()));
        		
        	}
        	
        }
        
        return posicao_valida_aleatoria;
    }
    
    

	
}
//se jogada linha 1 entre 3 e 1 = rand.nextInt (3) +1;
//se jogada linha 2 entre 6 e 4 = rand.nextInt (6) +4;
//se jogada linha 3 entre 9 e 7 = rand.nextInt (9) +7;
// se nao retorna posicao_valida_aleatoria
