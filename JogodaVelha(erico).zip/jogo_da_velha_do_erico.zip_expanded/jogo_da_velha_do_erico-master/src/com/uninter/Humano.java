package com.uninter;

import java.util.ArrayList;
import java.util.Scanner;

public class Humano extends Jogador {
    private Scanner teclado = new Scanner(System.in);
    String jogada = new String();
    @Override
    public String escolhe_jogada(ArrayList<String> posicoes_validas,String jogada_oponente,boolean is_jogada_oponente) {
        /* Print Escolha sua jogada dentre as posicoes validas*/
        //Se jogada estiver dentro das validas
        jogada = this.teclado.next();
        while(!posicoes_validas.contains(jogada)){
            System.out.println("Posicao invalida, tente novamente!");
            jogada = this.teclado.next();
        }
        return jogada;
        //Se nao, de novo
    }
}