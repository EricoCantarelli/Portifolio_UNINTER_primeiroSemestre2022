package com.uninter;

import java.util.ArrayList;
import java.util.Random;

public class ComputadorC extends Jogador{
   
	@Override
    public String escolhe_jogada(ArrayList<String> posicoes_validas,String jogada_oponente,boolean is_jogada_oponente) {
		Random rand = new Random();
        String posicao_valida_aleatoria = "";
        Tabuleiro tab = new Tabuleiro();
        int jogada_int = Integer.parseInt(jogada_oponente);
        boolean valido;
        if((jogada_int >= 4) && (jogada_int <= 8)) {
        	//int x = ran.nextInt(max_val) + min_val;
        	int randlinha = rand.nextInt(8)+ 4;
        	valido = tab.validarjogada(String.valueOf(randlinha),posicoes_validas);
        	if(valido == true) {
        		posicao_valida_aleatoria = (String.valueOf(randlinha));	
        	} else {
        		posicao_valida_aleatoria = posicoes_validas.get(rand.nextInt(posicoes_validas.size()));
        		
        	}
        	}
        return posicao_valida_aleatoria;
	}
       
    
}

//se jogada entre 8 e 4, rand.nextInt(8) +4;
//se nao retorna posicao_valida_aleatoria
