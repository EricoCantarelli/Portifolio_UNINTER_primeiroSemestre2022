package com.uninter;

import java.util.ArrayList;
import java.util.Scanner;

public class Jogo {

	public static void main(String[] args) {
		try (Scanner teclado = new Scanner(System.in)) {
			Tabuleiro tabuleiro = new Tabuleiro();

			Humano jogador = new Humano();
			Jogador oponente = new Jogador();

			System.out.println("Jogar contra humano ou computador?\n- 1 para Humano\n- 2 para Computador");
			int tipo_de_oponente = teclado.nextInt();

			while (tipo_de_oponente != 1 && tipo_de_oponente != 2) {
				System.out.println("Insira um numero valido\n");
				System.out.println("Jogar contra humano ou computador?\n- 1 para Humano\n- 2 para Computador");
				tipo_de_oponente = teclado.nextInt();
			}

			if (tipo_de_oponente == 1) {
				oponente = new Humano();
			}

			else if (tipo_de_oponente == 2) {
				System.out.println("Selecione a dificuldade 1, 2 ou 3\n");
				int opcao = teclado.nextInt();

				while (opcao != 1 && opcao != 2 && opcao != 3) {
					System.out.println("Insira um numero valido\n");
					System.out.println("Selecione a dificuldade 1, 2 ou 3\n");
					opcao = teclado.nextInt();
				}
				
				if (opcao == 1) {
					oponente = new ComputadorA();
				} else if (opcao == 2) {
					oponente = new ComputadorB();
				} else if (opcao == 3) {
					oponente = new ComputadorC();
				}
			}

			System.out.println("Jogo da Velha :3");
			int turno = 0;
			String[][] tabuleiro_atualizado;
			ArrayList<String> posicoes_validas;
			String jogada_escolhida = "";
			String X = new String("X");
			String O = new String("O");
			String vencedor = new String("null");

			while (true) {

				tabuleiro.visualizar();

				if (turno % 2 == 0) {
					System.out.println("----------------------\n");
					System.out.println("Jogador 1, escolha sua jogada:");
					tabuleiro_atualizado = tabuleiro.recebe_tabuleiro();
					posicoes_validas = jogador.posicoes_de_jogada_validas(tabuleiro_atualizado);
					jogada_escolhida = jogador.escolhe_jogada(posicoes_validas,"0",false);
					tabuleiro.Jogada(jogada_escolhida, X);
					turno++;
					vencedor = tabuleiro.Vitoria(turno);
					if (vencedor != "null") {
						System.out.println("----------------------\n");
						tabuleiro.visualizar();
						System.out.println("----------------------\n");
						System.out.println("Jogador 1 ganhou! \n");
						break;
					}
					;
				}
				if (turno % 2 == 1) {
					System.out.println("----------------------\n");
					System.out.println("Jogador 2, escolha sua jogada:");
					tabuleiro_atualizado = tabuleiro.recebe_tabuleiro();
					posicoes_validas = oponente.posicoes_de_jogada_validas(tabuleiro_atualizado);
					String jogada_oponente = jogada_escolhida;
					jogada_escolhida = oponente.escolhe_jogada(posicoes_validas,jogada_oponente,true);
					tabuleiro.Jogada(jogada_escolhida, O);
					turno++;
					vencedor = tabuleiro.Vitoria(turno);
					if (vencedor != "null") {
						System.out.println("----------------------\n");
						tabuleiro.visualizar();
						System.out.println("----------------------\n");
						System.out.println("Jogador 2 ganhou! \n");
						break;
					}
					;
				}

			}

		}
	}
}