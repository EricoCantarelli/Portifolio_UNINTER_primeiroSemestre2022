package com.uninter;

import java.util.ArrayList;

public class Jogador {
    public ArrayList<String> posicoes_de_jogada_validas(String[][] posicoes_tabuleiro) {
        String X = new String("X");
        String O = new String("O");
        ArrayList<String> posicoes_validas = new ArrayList<String>();
        for (int i = 0; i < posicoes_tabuleiro.length; i++) {
            for (int j = 0; j < posicoes_tabuleiro.length; j++) {
                if (!posicoes_tabuleiro[i][j].equals(X) && !posicoes_tabuleiro[i][j].equals(O)) {
                    posicoes_validas.add(posicoes_tabuleiro[i][j]);
                }
            }
        }
        return (posicoes_validas);
    }
    public String escolhe_jogada(ArrayList<String> posicoes_validas,String jogada_oponente,boolean is_jogada_oponente) {
        String nulo = new String("nulo");
        return nulo;
    }
   
}