package com.uninter;

import java.util.ArrayList;
import java.util.Random;

public class ComputadorA extends Jogador{    
    @Override
    public String escolhe_jogada(ArrayList<String> posicoes_validas,String jogada_oponente,boolean is_jogada_oponente) {
        Random rand = new Random();
        String posicao_valida_aleatoria = posicoes_validas.get(rand.nextInt(posicoes_validas.size()));
        return (posicao_valida_aleatoria);
    }
}