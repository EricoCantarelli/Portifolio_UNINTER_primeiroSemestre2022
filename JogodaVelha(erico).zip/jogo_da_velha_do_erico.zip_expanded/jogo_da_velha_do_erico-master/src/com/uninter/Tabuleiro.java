package com.uninter;

import java.util.ArrayList;

public class Tabuleiro {
	private String[][] mat = { { "1", "2", "3" }, { "4", "5", "6" }, { "7", "8", "9" } }; // adiciona-se encapsulamento
	// 1 - X - Jogador humano
	// -1 - O - Computador
	// 0 - Espa�o vazio
	// public int situacao() { //metodo pendente... relacionar com metodos ja
	// implantados de validacao de jogo
	// criar logica de verificar quem venceu ou se empatou ou se o jogo continua
	// return 0;

	public String[][] recebe_tabuleiro(){
		return this.mat;
	}

	public String visualizar() {

		for (int i = 0; i < mat.length; i++) {// linhas
			for (int j = 0; j < mat.length; j++) {// colunas
				System.out.printf("  " + mat[i][j]);
			}
			System.out.println();
		}
		return null;

	}

	public boolean campo(String camp) {
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat.length; j++) {
				if (mat[i][j].equals(camp))
					return true;
			}
			
	
		}
		return false;
	}
	
	//metodo pra validar a jogada e retorna se ela � valida, sim ou nao
	public boolean validarjogada(String jogada,ArrayList<String> posicoes_validas) {
		for (int i = 0; i < posicoes_validas.size(); i++) {
			if(jogada.equals(posicoes_validas.get(i))) {
				return true;
			}
		}
		return false;
		
		}

	public void Jogada(String camp, String jog) { // metodo para a jogada no tabuleiro
		if (camp.equals("1"))
			mat[0][0] = jog;
		else if (camp.equals("2"))
			mat[0][1] = jog;
		else if (camp.equals("3"))
			mat[0][2] = jog;
		else if (camp.equals("4"))
			mat[1][0] = jog;
		else if (camp.equals("5"))
			mat[1][1] = jog;
		else if (camp.equals("6"))
			mat[1][2] = jog;
		else if (camp.equals("7"))
			mat[2][0] = jog;
		else if (camp.equals("8"))
			mat[2][1] = jog;
		else if (camp.equals("9"))
			mat[2][2] = jog;
	}

	public String Vitoria(int turno) { // metodo de vitoria
		String[] V = new String[8];
		String vencedor = "null";
		if (turno == 9) {
			vencedor = "Empate";

		}
        //linha
		V[0] = mat[0][0] + mat[0][1] + mat[0][2];
		V[1] = mat[1][0] + mat[1][1] + mat[1][2];
		V[2] = mat[2][0] + mat[2][1] + mat[2][2];
		//coluna
		V[3] = mat[0][0] + mat[1][0] + mat[2][0];
		V[4] = mat[0][1] + mat[1][1] + mat[2][1];
		V[5] = mat[0][2] + mat[1][2] + mat[2][2];
		//diagonal
		V[6] = mat[0][0] + mat[1][1] + mat[2][2];
		V[7] = mat[0][2] + mat[1][1] + mat[2][0];

		for (int i = 0; i < V.length; i++) {
			if (V[i].equals("XXX")) {
				vencedor = "Jogador 1";
			} else if (V[i].equals("OOO")) {
				vencedor = "Jogador 2";

			}
		}

		return vencedor;

	}

}


/*
Se for responsabilidade do tabuleiro de validar a jogada, como funcionaria?

Funcao valida_jogada(jogada_jogador){
	    ArrayList<String> posicoes_validas = new ArrayList<String>();
    for (int i = 0; i < posicoes_tabuleiro.length; i++) {
        for (int j = 0; j < posicoes_tabuleiro.length; j++) {
            if (!posicoes_tabuleiro[i][j].equals('X') && !posicoes_tabuleiro[i][j].equals('O')) {
                posicoes_validas.add(posicoes_tabuleiro[i][j]);
            }
        }
    }
    return(posicoes_validas);
}

*/