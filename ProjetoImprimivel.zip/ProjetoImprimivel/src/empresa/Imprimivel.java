package empresa;

public interface Imprimivel {
	
	void imprimir();

}
